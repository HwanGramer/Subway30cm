const LIVE_STATION = 'http://swopenAPI.seoul.go.kr/api/subway/52704355736d616e34354953525a42/json/realtimeStationArrival/0/10/';

const BOKJOBDO = 'https://apis.openapi.sk.com/puzzle/congestion-train/rltm/trains/'; //? 뒤에 /호선번호/열차번호 붙히면됨

const BOKJOBDO_KEY = 'l7xxb228b40842d14359a20852e07d7e59f6';

const STATIONCODE_URL = 'http://openapi.seoul.go.kr:8088/754c67774c6d616e313032734d764461/json/SearchSTNBySubwayLineInfo/1/5/ /'; 
//? 지하철 노선이름의 역코드를 알려주는 API 마지막에 역이름 하고 호선이름 붙히면됨.

const TRAINTIMEBOKJOBDO = 'https://apis.openapi.sk.com/puzzle/congestion-train/stat/stations/'; //? 뒤에 역사코드 열차 시간복잡도

const CARTIMEBOKJOBDO = 'https://apis.openapi.sk.com/puzzle/congestion-car/stat/stations/'; //? 열차 칸별 시간복잡도 

module.exports = {LIVE_STATION , BOKJOBDO , BOKJOBDO_KEY , STATIONCODE_URL , TRAINTIMEBOKJOBDO , CARTIMEBOKJOBDO};
//?지하철 실시간 도착정보 마지막문자열에 역이름만 넣으면됨