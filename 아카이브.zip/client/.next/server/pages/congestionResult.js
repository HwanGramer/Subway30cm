"use strict";
(() => {
var exports = {};
exports.id = 251;
exports.ids = [251];
exports.modules = {

/***/ 184:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "N": () => (/* binding */ getExpressTrainCongestion),
  "T": () => (/* binding */ getRegularTrainCongestion)
});

;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
;// CONCATENATED MODULE: ./src/utils/getJson.ts
function getJson(value) {
    return JSON.stringify(value, null, 2);
}
/* harmony default export */ const utils_getJson = (getJson);

;// CONCATENATED MODULE: ./src/utils/request.ts


const BASE_URL = `${"http://localhost:8081/api"}`;
const instance = external_axios_default().create({
    baseURL: BASE_URL,
    timeout: 3000,
    headers: {
        "Content-Type": "application/json"
    }
});
instance.interceptors.response.use((response)=>response
, errorHandler);
if (false) {}
function errorHandler(e) {
    if (!e.response) throw {
        status: undefined,
        data: {
            message: e.message
        }
    };
    // eslint-disable-next-line no-console
    console.log(`[Error Data]: ${utils_getJson(e.response.data)}`);
    throw e.response;
}
/* harmony default export */ async function request(args) {
    const { data  } = await instance(args);
    return data;
};

;// CONCATENATED MODULE: ./src/api/subway/index.ts

const PATH = "subway";
function getRegularTrainCongestion({ line , stationName , way  }) {
    const encodedStationName = encodeURIComponent(stationName);
    const encodedWay = encodeURIComponent(way);
    return request({
        url: `/${PATH}/${line}/${encodedStationName}/${encodedWay}`,
        method: "get"
    });
}
function getExpressTrainCongestion({ line , stationName , way , fest  }) {
    const encodedStationName = encodeURIComponent(stationName);
    const encodedWay = encodeURIComponent(way);
    return request({
        url: `subway/${line}/${encodedStationName}/${encodedWay}/${fest}`,
        method: "get"
    });
}



/***/ }),

/***/ 50:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


function ArrivalInfo({ congestion  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "title",
                children: "\uC5F4\uCC28 \uB3C4\uCC29 \uC815\uBCF4"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "curStation",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "info",
                        children: "\uD604\uC7AC\uC704\uCE58"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "station",
                        children: congestion.data?.msg2
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "arrivalTime",
                children: [
                    congestion.data?.msg1,
                    " "
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArrivalInfo);
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-95cbd2f8-0"
})`
  width: 100%;
  height: 150px;
  border-top: 1px solid lightgray;
  background: #ffffff 0% 0% no-repeat padding-box;
  opacity: 1;
  border-radius: 25px;
  padding: 1px;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 100px;

  .title {
    margin-top: 20px;
    font-weight: 500;
  }

  .arrivalTime {
    font-weight: 500;
    margin-top: 20px;
    color: #c53715;
  }
  .curStation {
    width: 80%;
    margin-top: 10px;
    height: 40px;
    border-bottom: 1px solid lightgray;
    align-items: center;
    display: flex;
    justify-content: space-between;

    & > .info {
      font-weight: 500;
    }

    & > .station {
      color: #858585;
      font-weight: 345;
    }
  }
`;


/***/ }),

/***/ 934:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ congestionResult_CongestionInfo)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(755);
;// CONCATENATED MODULE: ./src/stores/MinimumCongestionCart.ts

const MinimumCongestionCart = (0,external_recoil_.atom)({
    key: "minimumCongestionCart",
    default: 0
});
/* harmony default export */ const stores_MinimumCongestionCart = (MinimumCongestionCart);

;// CONCATENATED MODULE: ./src/components/congestionResult/TrainCongestion.tsx






function TrainCongestion({ bokjobdo  }) {
    const [minimumCart, setMinimumCart] = (0,external_recoil_.useRecoilState)(stores_MinimumCongestionCart);
    const InvalidCongeston = (0,external_react_.useCallback)(()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("h1", {
            style: {
                color: "#143790",
                fontWeight: "600"
            },
            children: "\uD574\uB2F9 \uC5ED\uC758 \uC2E4\uC2DC\uAC04 \uC5F4\uCC28 \uD63C\uC7A1\uB3C4\uB294 \uC900\uBE44\uC911\uC785\uB2C8\uB2E4 :)"
        });
    }, []);
    //순서를 먼저 정하고 0.순서로 opacity 계산
    const getOpacity = (0,external_react_.useCallback)((cartCongestion, index)=>{
        const newLine = bokjobdo.line.map((item)=>{
            return Number(item);
        });
        newLine.sort((a, b)=>a - b
        );
        const order = newLine.findIndex((item)=>item === cartCongestion
        );
        if (order === 0) setMinimumCart(index + 1);
        if (Math.max.apply(null, newLine) === 0) return 0.1;
        if (cartCongestion === Math.max.apply(null, newLine)) return 1;
        return Number(`0.${order + 1}`);
    }, [
        bokjobdo,
        setMinimumCart
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Wrapper, {
        children: [
            bokjobdo.suc === false ? /*#__PURE__*/ jsx_runtime_.jsx(InvalidCongeston, {}) : /*#__PURE__*/ jsx_runtime_.jsx(Train, {
                children: bokjobdo.line.map((item, index)=>{
                    const opacity = getOpacity(Number(item), index);
                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cart",
                        style: {
                            opacity: `${opacity}`
                        },
                        children: index + 1
                    }, index);
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(InfoImageWrapper, {
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: `/assets/images/congestionInfo.png`,
                    alt: "arrow",
                    width: 105,
                    height: 25
                })
            })
        ]
    });
}
/* harmony default export */ const congestionResult_TrainCongestion = (TrainCongestion);
const Wrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-7e99843-0"
})`
  width: 90%;
`;
const InfoImageWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-7e99843-1"
})`
  width: 100%;
  display: flex;
  justify-content: center;
  margin-top: 15px;
`;
const Train = external_styled_components_default().div.withConfig({
    componentId: "sc-7e99843-2"
})`
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  .cart {
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 6px;
    height: 30px;
    width: 6vw;
    color: #ffffff;
    background: #273a6e;
  }
`;

;// CONCATENATED MODULE: ./src/components/congestionResult/TrainState.tsx



function inRange(x, min, max) {
    return (x - min) * (x - max) <= 0;
}
function TrainState({ aver: aver1  }) {
    const state = (0,external_react_.useCallback)((aver)=>{
        //0~33 매우쾌적: 좌석에 앉아서 가실 수 있습니다.
        //34~58 쾌적: 좌석에 자리는 없지만 혼잡도가 낮습니다.
        //59~99 혼잡: 좌석에 자리가 없으며 혼잡한 상태입니다.
        //100~149 매우혼잡: 좌석에 자리가 없으며 접촉이 있을만큼 매우 혼잡합니다.
        //150~230 극심한 혼잡: 발 디딜 틈조차 없을 만큼 혼잡한 상태입니다.
        if (inRange(aver, 0, 33)) return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "state",
            style: {
                color: "#D6d650"
            },
            children: "\uB9E4\uC6B0\uCF8C\uC801: \uC88C\uC11D\uC5D0 \uC549\uC544\uC11C \uAC00\uC2E4 \uC218 \uC788\uC2B5\uB2C8\uB2E4."
        });
        else if (inRange(aver, 34, 58)) return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "state",
            style: {
                color: "green"
            },
            children: "\uCF8C\uC801: \uC88C\uC11D\uC5D0 \uC790\uB9AC\uB294 \uC5C6\uC9C0\uB9CC \uD63C\uC7A1\uB3C4\uAC00 \uB0AE\uC2B5\uB2C8\uB2E4."
        });
        else if (inRange(aver, 59, 99)) return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "state",
            style: {
                color: "#B70508"
            },
            children: "\uD63C\uC7A1: \uC88C\uC11D\uC5D0 \uC790\uB9AC\uAC00 \uC5C6\uC73C\uBA70 \uD63C\uC7A1\uD55C \uC0C1\uD0DC\uC785\uB2C8\uB2E4."
        });
        else if (inRange(aver, 100, 149)) return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "state",
            style: {
                color: "#C9151a"
            },
            children: "\uB9E4\uC6B0\uD63C\uC7A1: \uC811\uCD09\uC774 \uC788\uC744\uB9CC\uD07C \uB9E4\uC6B0 \uD63C\uC7A1\uD569\uB2C8\uB2E4."
        });
        else return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "state",
            style: {
                color: "#F90004"
            },
            children: "\uBC1C \uB514\uB51C \uD2C8\uC870\uCC28 \uC5C6\uC744 \uB9CC\uD07C \uD63C\uC7A1\uD55C \uC0C1\uD0DC\uC785\uB2C8\uB2E4."
        });
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(TrainState_Wrapper, {
        children: state(aver1)
    });
}
/* harmony default export */ const congestionResult_TrainState = (TrainState);
const TrainState_Wrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-db5013dc-0"
})`
  width: 100%;
  display: flex;
  justify-content: center;
  margin-top: 15px;
  .state {
    font-weight: 520;
    font-size: 4vw;
    font-family: 'Droid Sans Mono';
  }
`;

;// CONCATENATED MODULE: ./src/components/congestionResult/MinimumCongestionCart.tsx




function MinimumCongestionCart_MinimumCongestionCart() {
    const [minimumCart, setMinimumCart] = (0,external_recoil_.useRecoilState)(stores_MinimumCongestionCart);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MinimumCongestionCart_Wrapper, {
        children: [
            "\uBCF5\uC2E4\uC774 \uCD94\uCC9C PICK! ",
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                className: "cart",
                children: [
                    " ",
                    minimumCart,
                    " \uBC88\uC9F8 \uCE78"
                ]
            })
        ]
    });
}
/* harmony default export */ const congestionResult_MinimumCongestionCart = (MinimumCongestionCart_MinimumCongestionCart);
const MinimumCongestionCart_Wrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-8f8437f9-0"
})`
  font-weight: 500;
  .cart {
    color: #858585;
    font-weight: 450;
  }
`;

;// CONCATENATED MODULE: ./src/components/congestionResult/CongestionInfo.tsx






function CongestionInfo({ congestion  }) {
    const { query  } = (0,router_.useRouter)();
    // console.log(congestion)
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CongestionInfo_Wrapper, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Direction, {
                children: congestion.data?.trainLineNm
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CurrentStationWrapper, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CurrentStation, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "title",
                                children: "\uD604\uC7AC\uC5ED"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "line",
                                children: query.line
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "station",
                                children: query.station
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CongesitonWrapper, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "title",
                                children: "\uD0C0\uC2E4 \uC5F4\uCC28 \uC815\uBCF4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "train_number",
                                children: congestion.data?.trainNumber
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(TrainCongestionWrapper, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "info",
                        children: "\uD574\uB2F9 \uC5F4\uCC28\uC758 \uCE78\uBCC4 \uD63C\uC7A1\uB3C4 \uCC28\uC774 \uC815\uBCF4 "
                    }),
                    !!congestion?.data?.BokJobDo && /*#__PURE__*/ jsx_runtime_.jsx(congestionResult_TrainCongestion, {
                        bokjobdo: congestion?.data?.BokJobDo
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(TrainWholeCongestionWrapper, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "info",
                        children: "\uD574\uB2F9 \uC5F4\uCC28\uC758 \uC804\uCCB4 \uD63C\uC7A1\uB3C4 \uC815\uBCF4"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(congestionResult_TrainState, {
                        aver: Number(congestion.data?.BokJobDo.aver)
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MinimumCartWrapper, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(congestionResult_MinimumCongestionCart, {})
            })
        ]
    });
}
/* harmony default export */ const congestionResult_CongestionInfo = (CongestionInfo);
const CongestionInfo_Wrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-c2e1d0ae-0"
})`
  width: 100%;
  height: 500px;
  background: #ffffff 0% 0% no-repeat padding-box;
  opacity: 1;
  border-radius: 25px;
`;
const Direction = external_styled_components_default().div.withConfig({
    componentId: "sc-c2e1d0ae-1"
})`
  font-family: sans-serif;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0 10px 0;
  height: 40px;
  border-bottom: 1px solid lightgray;
  color: #4d4d4d;
  opacity: 1;
`;
const CurrentStationWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-c2e1d0ae-2"
})`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 25px;
`;
const CurrentStation = external_styled_components_default().div.withConfig({
    componentId: "sc-c2e1d0ae-3"
})`
  width: 70%;
  height: 40px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid lightgray;

  .title {
    font-weight: 500;
  }

  .line {
    color: #858585;
    font-weight: 330;
  }

  .station {
    color: #858585;
    font-weight: 330;
  }
`;
const CongesitonWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-c2e1d0ae-4"
})`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 30px;
  border-top: 1px solid lightgray;

  .title {
    font-weight: 500;
    margin-top: 20px;
  }

  .train_number {
    color: #858585;
    font-weight: 330;
    margin-top: 5px;
  }
`;
const TrainCongestionWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-c2e1d0ae-5"
})`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 25px;

  .info {
    margin-bottom: 10px;
    font-weight: 440;
    font-size: 15px;
    font-family: 'Noto Sans Gothic';
    color: #c53715;
  }
`;
const TrainWholeCongestionWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-c2e1d0ae-6"
})`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 40px;

  .info {
    margin-bottom: 10px;
    font-weight: 440;
    font-size: 15px;
    font-family: 'Noto Sans Gothic';
    color: #c53715;
  }
`;
const MinimumCartWrapper = external_styled_components_default().div.withConfig({
    componentId: "sc-c2e1d0ae-7"
})`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 35px;
`;


/***/ }),

/***/ 770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);




function ReturnButton() {
    const { push  } = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            onClick: ()=>{
                push("/");
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                src: `/assets/images/returnArrow.png`,
                alt: "arrow",
                width: 35,
                height: 35
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReturnButton);
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-4b99528a-0"
})`
  position: absolute;
  top: 40px;
`;


/***/ }),

/***/ 434:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(590);
/* harmony import */ var _api_subway__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(184);
/* harmony import */ var _components_congestionResult_ReturnButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(770);
/* harmony import */ var _components_congestionResult_CongestionInfo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(934);
/* harmony import */ var _components_congestionResult_ArrivalInfo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(50);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__]);
react_toastify__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function CongestionResult(props) {
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (props.suc === false) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error("\uC5F4\uCC28 \uC815\uBCF4\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4.");
        }
    }, [
        props
    ]);
    const InvalidTrain = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                width: "100%",
                display: "flex",
                justifyContent: "center"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                style: {
                    position: "absolute",
                    top: "50%",
                    color: "white",
                    width: "fit-content"
                },
                children: "\uC5F4\uCC28 \uC815\uBCF4\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4!"
            })
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: props.suc === false ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {
                    position: "top-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InvalidTrain, {})
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_congestionResult_ReturnButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_congestionResult_CongestionInfo__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    congestion: props
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_congestionResult_ArrivalInfo__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    congestion: props
                })
            ]
        })
    });
}
async function getServerSideProps(context) {
    const { query  } = context;
    const { line , speed , direction , station  } = query;
    const lineObj = {
        "1\uD638\uC120": "one",
        "2\uD638\uC120": "two",
        "3\uD638\uC120": "three",
        "4\uD638\uC120": "four",
        "5\uD638\uC120": "five",
        "6\uD638\uC120": "six",
        "7\uD638\uC120": "seven",
        "8\uD638\uC120": "eight",
        "9\uD638\uC120": "nine"
    };
    const props = {
        suc: null,
        data: null
    };
    try {
        if (line === "1\uD638\uC120" || line === "9\uD638\uC120") {
            const response = await (0,_api_subway__WEBPACK_IMPORTED_MODULE_3__/* .getExpressTrainCongestion */ .N)({
                line: lineObj[line],
                stationName: String(station),
                way: String(direction),
                fest: Number(speed)
            });
            //@ts-ignore
            props.suc = props.data = response.suc;
            //@ts-ignore
            props.data = !!response.suc && response.data;
        } else if (line === "2\uD638\uC120" || line === "3\uD638\uC120" || line === "4\uD638\uC120" || line === "5\uD638\uC120" || line === "6\uD638\uC120" || line === "7\uD638\uC120" || line === "8\uD638\uC120") {
            const response = await (0,_api_subway__WEBPACK_IMPORTED_MODULE_3__/* .getRegularTrainCongestion */ .T)({
                line: lineObj[line],
                stationName: String(station),
                way: String(direction)
            });
            //@ts-ignore
            props.suc = response.suc;
            //@ts-ignore
            props.data = !!response.suc && response.data;
        }
    } catch (e) {
    //todo 예외처리
    }
    return {
        props
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CongestionResult);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [686,675], () => (__webpack_exec__(434)));
module.exports = __webpack_exports__;

})();