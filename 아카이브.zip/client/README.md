# JAM PACKED SUBWAY - FRONT
#### 서울 지하철의 실시간 칸별 혼잡도를 제공해주기위한 WEB-APP


## Tech-Stack
- NextJS
- Typescript
- Recoil
- Styled-BreackPoints
- Styled-Components
- Formik
- React-Toastify

