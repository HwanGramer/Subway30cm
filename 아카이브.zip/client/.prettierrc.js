module.exports = {
  semi: false,
  trailingComma: 'none',
  singleQuote: true,
  printWidth: 120,
  bracketSpacing: false,
  tabWidth: 2
}
