function getJson(value: any) {
  return JSON.stringify(value, null, 2)
}

export default getJson
