const FileType = {
  image: 'image',
  file: 'file'
}

export default FileType
