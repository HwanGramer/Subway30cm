const FileKinds = {
  banners: 'banners',
  products: 'products',
  users: 'users',
  etc: 'etc'
}

export default FileKinds
