const PasswordPattern = new RegExp('^[0-9a-zA-Z!@#$%^&*()?+-_~=/]{6,40}$')

export default PasswordPattern
