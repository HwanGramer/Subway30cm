function usePostProductsMutation() {}

export default usePostProductsMutation
