import React from 'react'

function AuthLayout() {
  return <div></div>
}

export default AuthLayout
